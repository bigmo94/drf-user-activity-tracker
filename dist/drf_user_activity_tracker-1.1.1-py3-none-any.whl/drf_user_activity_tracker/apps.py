from django.apps import AppConfig


class LoggerConfig(AppConfig):
    name = 'drf_user_activity_tracker'
    verbose_name = 'DRF User Activity Tracker'
